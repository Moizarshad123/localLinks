
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
  
    <!-- Till open and Close Modal -->
    

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/dist/js/popper.min.js')); ?>"  crossorigin="anonymous"></script>
<script src="<?php echo e(asset('admin/dist/js/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
<script>
  
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\localLinks\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>