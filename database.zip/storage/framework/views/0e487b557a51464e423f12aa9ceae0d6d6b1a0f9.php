
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Local Links - <?php echo $__env->yieldContent('title'); ?></title>

     <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    
    <?php echo $__env->make('admin.layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
        .toast-success {
            background-color: #51A351 !important; /* Success message background */
            color: #fff !important; /* Success message text color */
        }
        .toast-error {
            background-color: #D9534F !important; /* Error message background */
            color: #fff !important; /* Error message text color */
        }
    </style>

    <?php echo $__env->yieldContent('css'); ?>


</head>

<body>

    <!-- preloader -->
    <div class="preloader">
        <img src="<?php echo e(asset('admin/logo.jpg')); ?>" alt="logo">
        <div class="preloader-icon"></div>
    </div>
    <!-- ./ preloader -->

    
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- layout-wrapper -->
    <div class="layout-wrapper">

        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

        <!-- content -->
        <div class="content ">

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- ./ content -->

    </div>
    <!-- ./ layout-wrapper -->

    <?php echo $__env->make('admin.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <script>
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "timeOut": "3000",
            "extendedTimeOut": "1000",
            "positionClass": "toast-top-right", 
        };
    </script>

    <?php if(session()->has('success')): ?>
    <script type="text/javascript">  toastr.success('<?php echo e(session('success')); ?>');</script>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <script type="text/javascript"> toastr.error('<?php echo e(session('error')); ?>');</script>
    <?php endif; ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH D:\Projects\local_links\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>