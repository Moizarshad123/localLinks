
<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <h3>Edit Product</h3>
    <form method="POST" action="<?php echo e(route('admin.product.update', $product->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Category<span style="color: red">*</span></label>
                    <?php if($product->product_category_id == 14 || $product->product_category_id == 15): ?>
                        <select name="category_id" class="form-control" id="category_id" required>
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->id == 14 || $item->id == 15): ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $product->product_category_id ? "selected" : ""); ?>><?php echo e($item->title); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php else: ?>
                        <select name="category_id" class="form-control" id="category_id" required>
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->id == 12 || $item->id == 13): ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $product->product_category_id ? "selected" : ""); ?>><?php echo e($item->title); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endif; ?>
                   
                </div>
            </div>
            <?php if($product->product_category_id == 14 || $product->product_category_id == 15): ?>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Size<span style="color: red">*</span></label>
                        <input type="text" value="<?php echo e($product->title); ?>"  name="size" class="form-control" id="size" required>
                        
                    </div>
                </div>
            <?php else: ?>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Quantity<span style="color: red">*</span></label>
                       <input type="text" name="qty" value="<?php echo e($product->qty); ?>" class="form-control">
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Print Cost</label>
                    <input type="number" name="premium_standard_cost" min="1" class="form-control" value="<?php echo e($product->premium_standard_cost); ?>" aria-describedby="premium_standard_cost">
                </div>
            </div>
        </div>
        <?php if($product->product_category_id == 14 || $product->product_category_id == 15): ?>
            <div class="row">
                
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Studio LPM Total</label>
                        <input type="number" class="form-control" min="1" value="<?php echo e($product->studio_lpm_total); ?>" name="studio_lpm_total" aria-describedby="studio_lpm_total">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Media LPM Total</label>
                        <input type="number" class="form-control" min="1" value="<?php echo e($product->media_lpm_total); ?>" name="media_lpm_total" aria-describedby="media_lpm_total">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Studio Frame Total</label>
                        <input type="number" class="form-control" min="1" value="<?php echo e($product->studio_frame_total); ?>" name="studio_frame_total" aria-describedby="emailHelp">
                    </div>
                </div>
        
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Media Frame Total</label>
                        <input type="number" class="form-control" min="1" value="<?php echo e($product->media_frame_total); ?>" name="media_frame_total" aria-describedby="emailHelp">
                    </div>
                </div>
            </div>
        <?php endif; ?>
   
    
        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
$(document).ready(function () {

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/nasa/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>