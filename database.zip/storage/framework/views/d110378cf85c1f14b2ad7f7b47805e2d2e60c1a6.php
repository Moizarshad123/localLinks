
<?php $__env->startSection('title', 'Sales Returns'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- content -->
  <div class="content ">

    <div class="mb-4">
        <div class="row">
            <div class="col">
                <h3>Sales Returns</h3>
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-custom table-lg mb-0" id="ordersTable">
            <thead>
                <tr>
                    <th>Order No#</th>
                    <th>Customer Name</th>
                    <th>Order Creating Date</th>
                    <th>Order Return Date </th>
                    <th>Total Amount</th>
                    <th>Refund Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->order_number); ?></td>
                        <td><?php echo e($item->customer_name); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($item->creating_date))); ?></td>
                        <td><?php echo e(date('d-m-Y',strtotime($item->return_date)) ?? ""); ?></td>
                        <td><?php echo e($item->net_amount); ?></td>
                        <td><?php echo e($item->refund_amount); ?></td>
                        <td><?php echo e($item->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7"><h5 style="text-align:center">No Returns Found</h5></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- ./ content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/nasa/resources/views/admin/sales_return_report.blade.php ENDPATH**/ ?>