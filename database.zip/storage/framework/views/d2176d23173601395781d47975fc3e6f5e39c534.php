
<?php $__env->startSection('title', 'Create Order Big'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/bootstrap-docs.css')); ?>" type="text/css">

<link rel="stylesheet" href="<?php echo e(asset('admin/libs/form-wizard/jquery.steps.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/app.min.css')); ?>" type="text/css">
<style>
    .toggle-div {
        display: none;
        /* Hide divs by default */
    }

    .toggle-div.active {
        display: block;
        /* Show the active div */
    }

    #reOrderNumber {
        display: none;
    }

    #showEmails {
        display: none;
    }

    .addBtn {
        margin-top: 12px;
        margin-left: 80px;
    }

    .buttons-print {
        background: #595cd9;
        border: 1px solid #595cd9;
        color: white;
    }

    .buttons-csv {
        background: #ffc107;
        border: 1px solid #ffc107 !important;
        color: black;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <!-- content -->
    <h3>Assign Order Number(Small)</h3>
    <div class="content ">
        <div class="row">
            <div class="col-md-12">
                <form method="POST" action="<?php echo e(route('admin.assignNumberSmall')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Order Number</label>
                                <input readonly type="text" name="order_number" class="form-control" id="order_number"
                                    value="<?php echo e($order_number ?? ""); ?>" aria-describedby="emailHelp">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <button class="btn btn-primary" type="submit">Assign</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- ./ content -->
</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/nasa/resources/views/admin/small_orders/assign_order_small.blade.php ENDPATH**/ ?>