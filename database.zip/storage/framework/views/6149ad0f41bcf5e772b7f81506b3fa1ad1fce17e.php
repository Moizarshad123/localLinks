<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nasa</title>
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/app.min.css')); ?>" type="text/css">
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/icons/bootstrap-icons-1.4.0/bootstrap-icons.min.css')); ?>" type="text/css">

  <style>
    
    .text-center {
      text-align: center;
    }
    .align-amounts {
        display: flex;
        justify-content: space-around;
        width: 116%;
    }

    .label {
        font-weight: normal; /* Optional styling */
    }

    .amount {
        font-weight: bold; /* Optional styling */
    }
    .dotted-line::after {
        content: "";
        display: inline-block;
        border-bottom: 2px dotted #000;
        width: 30%;
        margin-left: 18px;
        /* margin-top: 5px; */
    }
    .dotted-line2::after {
        content: "";
        display: inline-block;
        border-bottom: 2px dotted #000;
        width: 19%;
        margin-left: 175px;
        /* margin-top: 5px; */
    }
    .customer-details .detail {
        display: flex;
        justify-content: space-between;
        margin-bottom: 5px; /* Optional spacing between rows */
        width: 83%;
        margin-left: 18px;
    }

    .customer-details .label {
        width: 175px; /* Adjust width as needed */
        font-weight: bold; /* Optional styling */
    }

    @media  print {
        body {
            margin: 0;
            padding: 0;
        }
    }


  </style>
</head>

<body>
  <!-- Modal Show Invoice POS-->
  <button onclick="javascript:window.print()" class="btn btn-outline-secondary d-none d-md-block btn-icon">
    <i class="bi bi-printer"></i> Print
</button>
  <div id="invoice-POS" style="padding: 13px;border: 1px solid black;max-width:400px;margin:0px auto">
    <div>
      <div class="info">
        <div class="text-center">
          <img src="<?php echo e(asset('admin/logo.jpg')); ?>" style="margin-top: 12px;" alt="" width="350px" height="auto">
        </div>
        <p class="text-center">
          <span>Shop 58, Al-Haidery Memorial Market, <br></span>
          <span>Block E, North Nazimabad Karachi.<br></span>
          <span>Phone # 0300-8286862,<br></span>
          <span>021-36636242-3, 021-36637185<br></span>
        </p>
        <hr style="border: none; width: 370px;border-bottom: 1px solid #000; text-align: center;">

        <h2 class="text-center" style="margin-top: 7px;">SALE RECEIPT</h2>
        <h3 class="text-center" style="margin-top: -15px;margin-bottom: 5px;">Job no: <?php echo e($order->order_number); ?></h3>
      <hr style="border: none; width: 370px;border-bottom: 1px solid #000; text-align: center;">

        <p class="customer-details">
          <span class="detail"><span class="label">Customer Name:</span> <?php echo e($order->customer_name ?? ""); ?></span>
          
          <span class="detail"><span class="label">Contact No:</span> <?php echo e($order->phone ?? ""); ?></span>
          
          
          
          <span class="detail"><span class="label">Booking Date/Time:</span> <?php echo e(date('d-m-Y H:i A', strtotime($order->created_at)) ?? ""); ?></span>
          
          <span class="detail"><span class="label">Collection Date/Time:</span> <?php echo e(date('d-m-Y', strtotime($order->delivery_date)).' '.date('H:i A', strtotime($order->delivery_time)) ?? ""); ?></span>
          
          <span class="detail"><span class="label">No Of Expose:</span> <?php echo e($order->no_of_persons ?? ""); ?></span>
          
          <span class="detail"><span class="label">Order Nature:</span> <?php echo e($order->category->title ?? ""); ?></span>
          
          <span class="detail"><span class="label">Order Status:</span> <?php echo e(ucfirst($order->order_nature) ?? ""); ?></span>
          
        </p>
      </div>
      <hr style="border: none; width: 370px; border-bottom: 2px dotted #000; text-align: center;">

      <table class="table_data" style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr>
            <th>
              Expose
            </th>
            <th>Size</th>
            <th>Country</th>
            <th>Qty</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
            <?php if(count($orderDetail) > 0): ?>
                <?php $__empty_1 = true; $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="text-center">
                    <td>
                        <span><?php echo e($item->expose ?? ""); ?></span>
                    </td>
                    <td><?php echo e($item->size ?? ""); ?></td>
                    <td><?php echo e($item->country ?? ""); ?></td>
                    <td><?php echo e($item->qty ?? ""); ?></td>
                    <td><?php echo e($item->total ?? ""); ?></td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                <?php endif; ?>
            <?php endif; ?>
        
          
        </tbody>
      </table>
      <hr style="border: none; width: 370px;border-bottom: 2px dotted #000; text-align: center;">

      <table class="table_data" style="width: 100%; border-collapse: collapse;">
        
        <tbody>
         
          <tr class="align-amounts">
           <th colspan="4"><span style="margin-left: -63px;margin-right: 59px;">Expose Charges:</span></th>
           <td colspan="1"><span><?php echo e(number_format($order->amount) ?? "0.00"); ?></span></td>
          </tr>
          <tr class="align-amounts">
            <th colspan="4"><span style="margin-left: -63px;margin-right: 25px;">Urgent Charges:</span></th>
            <td colspan="1"><span><?php echo e(number_format($order->order_nature_amount) ?? "0.00"); ?></span></td>
           </tr>
          <tr class="align-amounts">
            <th colspan="4"><span style="margin-left: -63px;margin-right: 59px;">Email Charges:</span></th>
            <td colspan="1"><span><?php echo e(number_format($order->email_amount) ?? "0.00"); ?></span></td>
           </tr>
        
          
        </tbody>
      </table>

      <span style="border: none; width: 170px;border-bottom: 2px dotted #000; text-align: center;"></span>
      <span class="dotted-line"></span>
      <span class="dotted-line2"></span>

<br>
      <table class="table_data" style="width: 100%; border-collapse: collapse;">
        
        <tbody>
         
          <tr class="align-amounts">
           <th colspan="4"><span style="margin-left: -63px;margin-right: 59px;">Grand Total:</span></th>
           <td colspan="1"><span><?php echo e(number_format($order->grand_total) ?? "0.00"); ?></span></td>
          </tr>
          <tr class="align-amounts">
            <th colspan="4"><span style="margin-left: -63px;margin-right: 59px;">Net Amount:</span></th>
            <td colspan="1"><span><?php echo e(number_format($order->net_amount) ?? "0.00"); ?></span></td>
           </tr>
           <tr class="align-amounts">
            <th colspan="4"><span style="margin-left: -63px;margin-right: 59px;">Paid Amount:</span></th>
            <td colspan="1"><span><?php echo e(number_format($order->amount_charged) ?? "0.00"); ?></span></td>
           </tr>
           <tr class="align-amounts">
            <th colspan="4"><span style="margin-left: -63px;margin-right: 11px;">Outstanding Amount:</span></th>
            <td colspan="1"><strong style="font-size: 28px;"><?php echo e(number_format($order->outstanding_amount) ?? "0.00"); ?></strong></td>
           </tr>
        
          
        </tbody>
      </table>
    </div>
  </div>

</body>

</html><?php /**PATH D:\Projects\Nasa\resources\views/admin/order_small_slip.blade.php ENDPATH**/ ?>