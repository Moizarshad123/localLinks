
<?php $__env->startSection('title', 'Till Report'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- content -->
  <div class="content ">

    <div class="mb-4">
        <div class="row">
            <div class="col-md-10">
                <h3>Till Report</h3>
            </div>
            <div class="col-md-2"> 
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-custom table-lg mb-0" id="ordersTable">
            <thead>
                <tr>
                    
                    <th>Till Date</th>
                    <th>Till Open Amount</th>
                    <th>Till Close Amount</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
             <?php $__empty_1 = true; $__currentLoopData = $till_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    
                    <td><?php echo e(isset($item->date) ? date('d-m-Y', strtotime($item->date)) : ""); ?></td>
                    <td>
                        <?php echo e($item->till_open_amount); ?>

                        
                    </td>
                    <td>
                        <?php echo e($item->till_close_amount); ?>

                        
                    </td>
                    <td>
                        <a target="blank" href="<?php echo e(url('admin/till-report-receipt/'.$item->date.'/'.$item->user_id)); ?>"><i class="fa-solid fa-print"></i></a>
                    </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 
             <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- ./ content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/nasa/resources/views/admin/tills/report.blade.php ENDPATH**/ ?>