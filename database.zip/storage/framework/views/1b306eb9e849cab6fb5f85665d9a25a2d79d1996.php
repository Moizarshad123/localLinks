
<?php $__env->startSection('title', 'Add Category'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <h3>Create Category</h3>
    <form method="POST" action="<?php echo e(route('admin.categories.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
     
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                   <input type="text" name="name" class="form-control">
                </div>
            </div>

            <div class="col-md-6">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Image</label>
                   <input type="file" name="image" class="form-control">
                </div>
            </div>

  
        </div>
    
        <button type="submit" class="btn btn-primary">Add</button>
    </form>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\localLinks\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>