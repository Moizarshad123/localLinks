
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
  
    <!-- Till open and Close Modal -->
    

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/dist/js/popper.min.js')); ?>"  crossorigin="anonymous"></script>
<script src="<?php echo e(asset('admin/dist/js/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
<script>
    $(document).on('click', '#tillOpenButton', function() {
        var tillForm = document.getElementById('tillForm');
        tillForm.action = "<?php echo e(route('admin.openTill')); ?>"; 
        $('#exampleModalLabel').text("Till Open");

        $('#tillOpenModal').modal('show'); 
    });
    $(document).on('click', '#tillCloseButton', function() {
        var tillForm = document.getElementById('tillForm');
        tillForm.action = "<?php echo e(route('admin.closeTill')); ?>"; 
        $('#exampleModalLabel').text("Till Close");
        $('#tillOpenModal').modal('show'); 
    });
    $(document).on('keyup', '#five_thousand', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 5000);
        $('#five_thousand_result').val(result);
    });
    $(document).on('keyup', '#one_thousand', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 1000);
        $('#one_thousand_result').val(result);
    });
    $(document).on('keyup', '#five_hundred', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 500);
        $('#five_hundred_result').val(result);
    });
    $(document).on('keyup', '#one_hundred', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 100);
        $('#one_hundred_result').val(result);
    });
    $(document).on('keyup', '#fifty', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 50);
        $('#fifty_result').val(result);
    });
    $(document).on('keyup', '#twenty', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 20);
        $('#twenty_result').val(result);
    });
    $(document).on('keyup', '#ten', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 10);
        $('#ten_result').val(result);
    });
    $(document).on('keyup', '#five', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 5);
        $('#five_result').val(result);
    });
    $(document).on('keyup', '#two', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 2);
        $('#two_result').val(result);
    });
    $(document).on('keyup', '#one', function() {
        let amount = $(this).val();
        let result = parseFloat(amount * 1);
        $('#one_result').val(result);
    });
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/mobile_app/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>