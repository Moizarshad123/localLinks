
<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <h3>Edit User</h3>
    <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Role<span style="color: red">*</span></label>
                    <select name="role_id" class="form-control" id="role_id" required>
                        <option value="">Select Role</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($user->role_id == $item->id ? "selected" : ""); ?>><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                   <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Mobile</label>
                   <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email<span style="color: red">*</span></label>
                   <input type="email" name="email" class="form-control" required value="<?php echo e($user->email); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Status</label>
                    <select name="status" class="form-control" id="status">
                      <option value="1" <?php echo e($user->status == 1 ? "selected" : ""); ?>>Active</option>
                      <option value="0" <?php echo e($user->status == 0 ? "selected" : ""); ?>>In-Active</option>

                    </select>
                </div>
            </div>
        </div>
    
        <button type="submit" class="btn btn-primary">Edit</button>
    </form>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/nasa/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>