
<?php $__env->startSection('title', 'Send Emails'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- content -->
  <div class="content ">

    <div class="mb-4">
        <div class="row">
            <div class="col">
                <h3>Send Emails</h3>
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-custom table-lg mb-0" id="ordersTable">
            <thead>
                <tr>
                    <th>Order#</th>
                    <th>Customer Name</th>
                    <th>Customer Mobile</th>
                    <th>Emails</th>
                    <th>Order Creating Date</th>
                    <th>Order Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->order_number); ?></td>
                        <td><?php echo e($item->customer_name); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->emails); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($item->creating_date))); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.markDone', $item->id)); ?>" class="btn btn-sm btn-success">Mark as Send</a>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">
                            <h4 class="text-center">No Email Found</h4>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>


</div>
<!-- ./ content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamiltob/public_html/nasa/resources/views/admin/emails.blade.php ENDPATH**/ ?>